dollar=float(input("What is the dollar amount?"))
age=int(input("What is the age of the buyer?"))
if 4.25<=dollar<=253:
    print("$","{:.2f}".format(dollar-3),"will be loaded onto the card.")
elif dollar<4.25:
    print("This amount is too low to purchase a card.")
elif dollar>253:
    print("This amount is too high to purchase a card.")
if 4.25<=dollar<=253 and 5<=age<=18:
    print("This card is eligible for a Youth Discount.")
elif 4.25<=dollar<=253 and age>=65:
    print("This card is eligible for a Senior Discount.")
elif 4.25<=dollar<=253 and 18<age<65:
    print("This card is not eligible for any discounts.")